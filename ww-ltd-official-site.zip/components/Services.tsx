import React from 'react';
import { SERVICES } from '../constants';
import { Service } from '../types';
import { BrainCircuit, Cloud, Headset, Check, Briefcase } from 'lucide-react';

interface ServicesProps {
  addToCart: (item: Service, type: 'service') => void;
}

const icons: Record<string, React.ReactNode> = {
  'BrainCircuit': <BrainCircuit size={32} />,
  'Cloud': <Cloud size={32} />,
  'Headset': <Headset size={32} />
};

export const Services: React.FC<ServicesProps> = ({ addToCart }) => {
  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900">Professional Services</h2>
          <p className="mt-4 text-slate-600">Expert solutions tailored to your business scale.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => (
            <div 
              key={service.id} 
              className={`relative rounded-2xl p-8 shadow-xl flex flex-col ${
                index === 1 
                  ? 'bg-slate-900 text-white ring-4 ring-brand-500/50' 
                  : 'bg-white text-slate-900 border border-slate-200'
              }`}
            >
              {index === 1 && (
                <div className="absolute top-0 right-0 -mt-3 -mr-3">
                  <span className="inline-flex items-center justify-center px-3 py-1 text-xs font-bold text-white bg-brand-500 rounded-full shadow-lg">
                    Popular
                  </span>
                </div>
              )}

              <div className={`p-3 rounded-lg w-fit mb-6 ${
                index === 1 ? 'bg-slate-800 text-brand-400' : 'bg-brand-50 text-brand-600'
              }`}>
                {icons[service.icon] || <Briefcase size={32}/>}
              </div>

              <h3 className="text-2xl font-bold mb-2">{service.name}</h3>
              <p className={`mb-6 text-sm ${index === 1 ? 'text-slate-400' : 'text-slate-500'}`}>
                {service.description}
              </p>

              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-extrabold tracking-tight">
                  ${service.price.toLocaleString()}
                </span>
                <span className={`ml-1 text-xl font-semibold ${index === 1 ? 'text-slate-400' : 'text-slate-500'}`}>
                  {service.billingType === 'One-time' ? '' : `/${service.billingType === 'Monthly' ? 'mo' : 'yr'}`}
                </span>
              </div>

              <ul className="mb-8 space-y-4 flex-1">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center">
                    <Check size={20} className={`mr-3 ${index === 1 ? 'text-brand-400' : 'text-brand-600'}`} />
                    <span className="text-sm font-medium">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => addToCart(service, 'service')}
                className={`w-full py-3 rounded-xl font-bold transition-all duration-200 ${
                  index === 1
                    ? 'bg-brand-500 text-white hover:bg-brand-400'
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                Select Plan
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};