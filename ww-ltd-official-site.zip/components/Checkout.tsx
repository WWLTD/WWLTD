import React, { useState } from 'react';
import { CartItem, ViewState } from '../types';
import { Trash2, CreditCard, Lock, CheckCircle2 } from 'lucide-react';

interface CheckoutProps {
  cart: CartItem[];
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
  clearCart: () => void;
  setView: (view: ViewState) => void;
}

export const Checkout: React.FC<CheckoutProps> = ({ cart, removeFromCart, updateQuantity, clearCart, setView }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'cart' | 'payment'>('cart');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    cardName: '',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + tax;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      clearCart();
      setView('success');
    }, 2000);
  };

  if (cart.length === 0 && step === 'cart') {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 bg-slate-50">
        <div className="w-24 h-24 bg-slate-200 rounded-full flex items-center justify-center mb-6 text-slate-400">
          <Trash2 size={40} />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Your cart is empty</h2>
        <p className="text-slate-600 mb-8">Looks like you haven't added any products or services yet.</p>
        <button 
          onClick={() => setView('products')}
          className="bg-brand-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-brand-700 transition-colors"
        >
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-8">
          {step === 'cart' ? 'Shopping Cart' : 'Secure Checkout'}
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Content Area */}
          <div className="lg:col-span-8 space-y-6">
            
            {step === 'cart' ? (
              // Step 1: Cart Items
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <ul className="divide-y divide-slate-100">
                  {cart.map((item) => (
                    <li key={item.id} className="p-6 flex items-center gap-6">
                      <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-md border border-slate-200 bg-slate-100">
                         {item.image ? (
                           <img src={item.image} alt={item.name} className="h-full w-full object-cover object-center" />
                         ) : (
                           <div className="h-full w-full flex items-center justify-center text-slate-400">
                             <BriefcaseIcon />
                           </div>
                         )}
                      </div>

                      <div className="flex flex-1 flex-col">
                        <div>
                          <div className="flex justify-between text-base font-medium text-slate-900">
                            <h3>{item.name}</h3>
                            <p className="ml-4">${(item.price * item.quantity).toLocaleString()}</p>
                          </div>
                          <p className="mt-1 text-sm text-slate-500">{item.type === 'service' ? item.billingType : 'Unit'}</p>
                        </div>
                        <div className="flex flex-1 items-end justify-between text-sm">
                          <div className="flex items-center border border-slate-300 rounded-lg">
                            <button 
                              onClick={() => updateQuantity(item.id, -1)}
                              className="px-3 py-1 hover:bg-slate-100 text-slate-600 font-bold disabled:opacity-50"
                              disabled={item.quantity <= 1}
                            >
                              -
                            </button>
                            <span className="px-2 py-1 text-slate-900 font-medium">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.id, 1)}
                              className="px-3 py-1 hover:bg-slate-100 text-slate-600 font-bold"
                            >
                              +
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => removeFromCart(item.id)}
                            className="font-medium text-red-600 hover:text-red-500 flex items-center gap-1"
                          >
                            <Trash2 size={16} /> Remove
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              // Step 2: Payment Form
              <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
                 <div className="flex items-center gap-2 text-slate-900 mb-6 pb-4 border-b border-slate-100">
                   <Lock size={20} className="text-brand-600" />
                   <h2 className="text-xl font-bold">Payment Details</h2>
                 </div>
                 
                 <form id="payment-form" onSubmit={handlePayment} className="space-y-6">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-700">Full Name</label>
                        <input required name="name" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-slate-50 p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition" placeholder="John Doe" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-700">Email Address</label>
                        <input required type="email" name="email" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-slate-50 p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition" placeholder="john@example.com" />
                      </div>
                   </div>

                   <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Billing Address</label>
                      <input required name="address" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-slate-50 p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition" placeholder="123 Business St, Tech City" />
                   </div>

                   <div className="pt-4">
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                       <div className="flex items-center gap-2 mb-4">
                         <CreditCard size={20} className="text-slate-500" />
                         <span className="text-sm font-medium text-slate-700">Card Information</span>
                       </div>
                       <div className="space-y-4">
                          <input required name="cardNumber" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-white p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none" placeholder="0000 0000 0000 0000" maxLength={19} />
                          <div className="grid grid-cols-2 gap-4">
                             <input required name="expiry" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-white p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none" placeholder="MM/YY" maxLength={5} />
                             <input required name="cvc" onChange={handleInputChange} className="w-full rounded-lg border-slate-300 bg-white p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none" placeholder="CVC" maxLength={3} type="password"/>
                          </div>
                       </div>
                     </div>
                   </div>
                 </form>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-4">
            <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-24">
              <h2 className="text-lg font-medium text-slate-900 mb-4">Order Summary</h2>
              
              <dl className="space-y-4 text-sm text-slate-600">
                <div className="flex justify-between">
                  <dt>Subtotal</dt>
                  <dd className="font-medium text-slate-900">${subtotal.toLocaleString()}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Estimated Tax (8%)</dt>
                  <dd className="font-medium text-slate-900">${tax.toLocaleString(undefined, { maximumFractionDigits: 2 })}</dd>
                </div>
                <div className="border-t border-slate-100 pt-4 flex justify-between items-center">
                  <dt className="text-base font-bold text-slate-900">Total</dt>
                  <dd className="text-xl font-bold text-brand-600">${total.toLocaleString(undefined, { maximumFractionDigits: 2 })}</dd>
                </div>
              </dl>

              <div className="mt-8">
                {step === 'cart' ? (
                  <button
                    onClick={() => setStep('payment')}
                    className="w-full rounded-xl bg-brand-600 px-6 py-4 text-sm font-bold text-white shadow-sm hover:bg-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 transition-all"
                  >
                    Proceed to Checkout
                  </button>
                ) : (
                  <button
                    type="submit"
                    form="payment-form"
                    disabled={isProcessing}
                    className="w-full rounded-xl bg-green-600 px-6 py-4 text-sm font-bold text-white shadow-sm hover:bg-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex justify-center items-center"
                  >
                    {isProcessing ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processing...
                      </span>
                    ) : (
                      `Pay $${total.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
                    )}
                  </button>
                )}
                
                {step === 'payment' && (
                  <button 
                    onClick={() => setStep('cart')}
                    className="w-full mt-4 text-sm text-slate-500 hover:text-slate-800 font-medium"
                  >
                    &larr; Back to Cart
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const BriefcaseIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
);
