import React, { useState } from 'react';
import { PRODUCTS } from '../constants';
import { Product } from '../types';
import { Plus, Check } from 'lucide-react';

interface ProductsProps {
  addToCart: (item: Product, type: 'product') => void;
}

export const Products: React.FC<ProductsProps> = ({ addToCart }) => {
  const [filter, setFilter] = useState<'All' | 'Hardware' | 'Software' | 'Accessories'>('All');
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());

  const filteredProducts = filter === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === filter);

  const handleAdd = (product: Product) => {
    addToCart(product, 'product');
    setAddedIds(prev => new Set(prev).add(product.id));
    setTimeout(() => {
      setAddedIds(prev => {
        const next = new Set(prev);
        next.delete(product.id);
        return next;
      });
    }, 1500);
  };

  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900">Our Products</h2>
          <p className="mt-4 text-slate-600">Premium hardware and software for professionals.</p>
        </div>

        {/* Filters */}
        <div className="flex justify-center mb-10 space-x-2 sm:space-x-4">
          {['All', 'Hardware', 'Software', 'Accessories'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === cat 
                  ? 'bg-brand-600 text-white shadow-md' 
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-shadow duration-300 overflow-hidden flex flex-col">
              <div className="h-48 w-full overflow-hidden bg-slate-200 relative">
                 <img 
                   src={product.image} 
                   alt={product.name}
                   className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                 />
                 <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-slate-900 shadow-sm">
                   {product.category}
                 </div>
              </div>
              
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-slate-900">{product.name}</h3>
                  <span className="text-lg font-bold text-brand-600">${product.price.toLocaleString()}</span>
                </div>
                
                <p className="text-slate-600 text-sm mb-4 flex-1">{product.description}</p>
                
                <ul className="text-sm text-slate-500 mb-6 space-y-1">
                  {product.features.map((feat, idx) => (
                    <li key={idx} className="flex items-center">
                      <span className="w-1.5 h-1.5 bg-brand-400 rounded-full mr-2"></span>
                      {feat}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleAdd(product)}
                  disabled={addedIds.has(product.id)}
                  className={`w-full py-3 px-4 rounded-xl flex items-center justify-center font-semibold transition-all duration-200 ${
                    addedIds.has(product.id)
                      ? 'bg-green-500 text-white cursor-default'
                      : 'bg-slate-900 text-white hover:bg-brand-600 active:scale-95'
                  }`}
                >
                  {addedIds.has(product.id) ? (
                    <>
                      <Check size={18} className="mr-2" /> Added
                    </>
                  ) : (
                    <>
                      <Plus size={18} className="mr-2" /> Add to Cart
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};