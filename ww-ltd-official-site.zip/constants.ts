import { Product, Service } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'WW Enterprise Server X1',
    description: 'High-performance rack server optimized for AI workloads and large-scale database management.',
    price: 4999.00,
    category: 'Hardware',
    image: 'https://picsum.photos/400/300?random=1',
    features: ['128-Core Processor', '2TB RAM Support', 'Redundant Power Supply']
  },
  {
    id: 'p2',
    name: 'Quantum Workstation Pro',
    description: 'The ultimate workstation for designers, engineers, and data scientists.',
    price: 2499.00,
    category: 'Hardware',
    image: 'https://picsum.photos/400/300?random=2',
    features: ['Liquid Cooling', 'NVIDIA RTX 4090', '4TB NVMe SSD']
  },
  {
    id: 'p3',
    name: 'SecureGateway Router',
    description: 'Enterprise-grade firewall and router for maximum network security.',
    price: 899.00,
    category: 'Accessories',
    image: 'https://picsum.photos/400/300?random=3',
    features: ['Deep Packet Inspection', 'VPN Support', '10GbE Ports']
  },
  {
    id: 'p4',
    name: 'WW Analytics Suite',
    description: 'Proprietary software for business intelligence and predictive analytics.',
    price: 599.00,
    category: 'Software',
    image: 'https://picsum.photos/400/300?random=4',
    features: ['Real-time Dashboards', 'AI Forecasting', 'Cloud Integration']
  },
  {
    id: 'p5',
    name: 'ErgoChair Ultimate',
    description: 'Ergonomic office chair designed for 24/7 comfort.',
    price: 1200.00,
    category: 'Accessories',
    image: 'https://picsum.photos/400/300?random=5',
    features: ['Lumbar Support', 'Breathable Mesh', '12-Year Warranty']
  },
  {
    id: 'p6',
    name: 'DevOps Toolkit License',
    description: 'Complete set of tools for CI/CD pipelines and automated testing.',
    price: 299.00,
    category: 'Software',
    image: 'https://picsum.photos/400/300?random=6',
    features: ['Unlimited Repos', 'Cloud Build', 'Security Scanning']
  }
];

export const SERVICES: Service[] = [
  {
    id: 's1',
    name: 'IT Infrastructure Consulting',
    description: 'Expert analysis and architectural design for your company IT needs.',
    price: 1500.00,
    billingType: 'One-time',
    features: ['Network Audit', 'Security Assessment', 'Hardware Recommendations'],
    icon: 'BrainCircuit'
  },
  {
    id: 's2',
    name: 'Cloud Migration Managed Service',
    description: 'Seamless transition of your legacy systems to the cloud.',
    price: 2500.00,
    billingType: 'Monthly',
    features: ['Zero Downtime Strategy', 'AWS/Azure/GCP', 'Post-migration Support'],
    icon: 'Cloud'
  },
  {
    id: 's3',
    name: '24/7 Dedicated Support',
    description: 'Round-the-clock priority support for critical business operations.',
    price: 999.00,
    billingType: 'Monthly',
    features: ['15-min Response Time', 'Dedicated Account Manager', 'On-site Support Options'],
    icon: 'Headset'
  }
];