import React, { useState } from 'react';
import { ViewState, CartItem, Product, Service } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Products } from './components/Products';
import { Services } from './components/Services';
import { Checkout } from './components/Checkout';
import { CheckCircle2, ArrowRight } from 'lucide-react';

export default function App() {
  const [view, setView] = useState<ViewState>('home');
  const [cart, setCart] = useState<CartItem[]>([]);

  // Simple toast notification state
  const [toast, setToast] = useState<{message: string, visible: boolean}>({ message: '', visible: false });

  const showToast = (message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast({ ...toast, visible: false }), 3000);
  };

  const addToCart = (item: Product | Service, type: 'product' | 'service') => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: 1,
          type,
          image: 'image' in item ? item.image : undefined,
          billingType: 'billingType' in item ? item.billingType : undefined
        },
      ];
    });
    showToast(`Added ${item.name} to cart`);
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) => 
      prev.map(item => {
        if (item.id === id) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      })
    );
  };

  const clearCart = () => setCart([]);

  const renderView = () => {
    switch (view) {
      case 'home':
        return <Hero setView={setView} />;
      case 'products':
        return <Products addToCart={addToCart} />;
      case 'services':
        return <Services addToCart={addToCart} />;
      case 'checkout':
        return (
          <Checkout 
            cart={cart} 
            removeFromCart={removeFromCart} 
            updateQuantity={updateQuantity}
            clearCart={clearCart}
            setView={setView}
          />
        );
      case 'success':
        return (
          <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
            <div className="bg-white p-8 md:p-12 rounded-2xl shadow-xl text-center max-w-lg w-full animate-in fade-in zoom-in duration-500">
              <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 size={48} className="text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Order Confirmed!</h2>
              <p className="text-slate-600 mb-8">
                Thank you for choosing WW LTD. Your order #WW-{Math.floor(Math.random() * 10000)} has been processed successfully. A confirmation email has been sent.
              </p>
              <button
                onClick={() => setView('home')}
                className="bg-brand-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-brand-700 transition-colors flex items-center justify-center gap-2 mx-auto w-full"
              >
                Return Home <ArrowRight size={18} />
              </button>
            </div>
          </div>
        );
      default:
        return <Hero setView={setView} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-900">
      {view !== 'success' && (
        <Navbar currentView={view} setView={setView} cartCount={cart.reduce((a, b) => a + b.quantity, 0)} />
      )}
      
      <main className="flex-grow">
        {renderView()}
      </main>

      {view !== 'success' && view !== 'checkout' && (
        <footer className="bg-slate-900 text-slate-400 py-12">
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-white text-lg font-bold mb-4">WW LTD</h3>
              <p className="max-w-xs text-sm">Empowering businesses with enterprise-grade solutions and world-class consulting since 2024.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => setView('home')} className="hover:text-white">About Us</button></li>
                <li><button onClick={() => setView('products')} className="hover:text-white">Products</button></li>
                <li><button onClick={() => setView('services')} className="hover:text-white">Services</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-6 mt-12 pt-8 border-t border-slate-800 text-xs text-center">
            &copy; 2024 WW LTD. All rights reserved.
          </div>
        </footer>
      )}

      {/* Toast Notification */}
      {toast.visible && (
        <div className="fixed bottom-4 right-4 bg-slate-900 text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-3 animate-in slide-in-from-bottom duration-300 z-50">
          <CheckCircle2 size={20} className="text-green-400" />
          <span className="font-medium">{toast.message}</span>
        </div>
      )}
    </div>
  );
}