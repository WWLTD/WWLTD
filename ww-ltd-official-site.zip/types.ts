export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Hardware' | 'Software' | 'Accessories';
  image: string;
  features: string[];
}

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number; // Base price or monthly
  billingType: 'One-time' | 'Monthly' | 'Yearly';
  features: string[];
  icon: string;
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  type: 'product' | 'service';
  image?: string;
  billingType?: string;
}

export type ViewState = 'home' | 'products' | 'services' | 'checkout' | 'success';